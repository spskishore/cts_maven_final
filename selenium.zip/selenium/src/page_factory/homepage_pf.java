package page_factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class homepage_pf {

	WebDriver dr;
	

	@FindBy(xpath="//div[@class='product_label']")
	WebElement product;
	
	@FindBy(xpath="//div[@class='inventory_container']/div/div[1]/div[2]/a/div")
	WebElement firstprod;
	
	
	public homepage_pf(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public String get_product(){
		
		return product.getText();
	}
	
	public String firstprod(){
		
		return firstprod.getText();
	}
	
}
