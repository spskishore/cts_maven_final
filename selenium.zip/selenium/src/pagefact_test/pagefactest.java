package pagefact_test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import page_factory.homepage_pf;
import page_factory.loginpage_pf;

public class pagefactest {
	
	WebDriver dr;
	loginpage_pf lp1;
	homepage_pf hp1;
	
	@BeforeClass
	public void launch_brow()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get("http://www.saucedemo.com/");
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	 @Test(priority=1)
	  public void test_title() {
		  
		  lp1=new loginpage_pf(dr);
		  String lp_title=lp1.get_title1();
		  Assert.assertTrue(lp_title.contains("Swag Labs"));
	  }
	 
	 @Test(priority=2)
	  public void test_loginpage() {
		  
		  lp1=new loginpage_pf(dr);
		  lp1.do_login("standard_user", "secret_sauce");
	
	  }
	

	  @Test(priority=3)
	  public void test_homepage() {
		  	
		  hp1=new homepage_pf(dr);	 
		  String actual_heading=hp1.get_product();
		  Assert.assertTrue(actual_heading.contains("Products"));
	  }
	  
	  @Test(priority=4)
	  public void test_homepag2() {
		  
		  hp1=new homepage_pf(dr);	  
		  String firstproduct=hp1.firstprod();
		  Assert.assertTrue(firstproduct.contains("Sauce Labs Backpack"));
	  }
}
