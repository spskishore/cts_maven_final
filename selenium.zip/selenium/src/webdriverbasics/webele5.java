package webdriverbasics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class webele5 {
	 static String xp;
	 String q="";
	public static  void extract() {
	
	
		int p1=xp.indexOf(':',0);
		int p2=xp.indexOf('A',0);
		String q=xp.substring(p1+=4, p2-=1);
		System.out.println(q);
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
		List g=dr.findElements(By.name("gender"));
		((WebElement) g.get(1)).click();
		
		List a=dr.findElements(By.name("ageGroup"));
		((WebElement) a.get(2)).click();
		
		dr.findElement(By.xpath("//*[@id='easycont']/div/div[2]/div[2]/div[2]/button")).click();
		
		 xp=dr.findElement(By.xpath("//*[@id='easycont']/div/div[2]/div[2]/div[2]/p[2]")).getText();
		webele5.extract();
	}

}
