package webdriverbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Registration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
		
	//----------------------------------------------------
		dr.findElement(By.xpath("//table[@class='Record']/tbody/tr[1]/td[2]/input")).sendKeys("spskishore1111");
		dr.findElement(By.xpath("//table[@class='Record']/tbody/tr[2]/td[2]/input")).sendKeys("qwerty");
		dr.findElement(By.xpath("//table[@class='Record']/tbody/tr[3]/td[2]/input")).sendKeys("kishore");
		dr.findElement(By.xpath("//table[@class='Record']/tbody/tr[4]/td[2]/input")).sendKeys("kumar");
		dr.findElement(By.xpath("//table[@class='Record']/tbody/tr[5]/td[2]/input")).sendKeys("spskriz@gmail.com");
		dr.findElement(By.xpath("//table[@class='Record']/tbody/tr[6]/td[2]/input")).sendKeys("first road");
		dr.findElement(By.xpath("//table[@class='Record']/tbody/tr[9]/td[2]/input")).sendKeys("newjersey");
		
		WebElement we= dr.findElement(By.name("state_id"));
		Select sel=new Select(we);
		sel.selectByVisibleText("Texas");
		
		dr.findElement(By.xpath("//table[@class='Record']/tbody/tr[11]/td[2]/input")).sendKeys("75011"); //zip
		
	
		
		WebElement c= dr.findElement(By.name("country_id"));
		Select sel1=new Select(c);
		sel1.selectByVisibleText("United States");
		
		WebElement s= dr.findElement(By.name("state_id"));
		Select sel2=new Select(s);
		sel2.selectByVisibleText("Texas");
		
		WebElement l= dr.findElement(By.name("language_id"));
		Select sel3=new Select(l);
		sel3.selectByVisibleText("English");
		
		WebElement a= dr.findElement(By.name("age_id"));
		Select sel4=new Select(a);
		sel4.selectByVisibleText("18-24");
		
		WebElement g= dr.findElement(By.name("gender_id"));
		Select sel5=new Select(g);
		sel5.selectByVisibleText("Male");
		
		WebElement e= dr.findElement(By.name("education_id"));
		Select sel6=new Select(e);
		sel6.selectByVisibleText("College");
		
		WebElement i= dr.findElement(By.name("income_id"));
		Select sel7=new Select(i);
		sel7.selectByVisibleText("under $25,000");
		
		
		dr.findElement(By.xpath("//input[@name='Insert']")).click();
		
		//--------------------------------------------------------------
		
		dr.findElement(By.xpath("//table[@class='Record']/tbody/tr/td/input")).sendKeys("spskishore1111");
		
		dr.findElement(By.xpath("//table[@class='Record']/tbody/tr[2]/td[2]/input")).click();
		
		//------------------------------------------------------------------------------------------------
		
		String usr_name=dr.findElement(By.xpath("/html/body/center/table[2]/tbody/tr/td/table[2]/tbody/tr[2]/td[1]/a")).getText();
		
		if(usr_name.compareTo("spskishore1111")==0){
			System.out.println("Login Successful");
		} else {
			System.out.println("Login Failed");
		}
		
		
	}

}
