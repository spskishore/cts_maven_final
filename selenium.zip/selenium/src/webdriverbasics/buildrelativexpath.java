package webdriverbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class buildrelativexpath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
		///-----------------------using text()
		dr.findElement(By.xpath("//label[text()='Email:']")).getText();
		dr.findElement(By.xpath("//label[text()='Password:']")).getText();
		dr.findElement(By.xpath("//label[text()='Remember me?']")).getText();
		
		//-----------------------using contains()
		dr.findElement(By.xpath("//label[contains(@for,'Em')]")).getText();
		dr.findElement(By.xpath("//label[contains(@for,'Pass')]")).getText();
		dr.findElement(By.xpath("//label[contains(@for,'Rem')]")).getText();
		
		//----------------------------------using contains and text()
		dr.findElement(By.xpath("//label[contains(text(),'Email:')]")).getText();
		dr.findElement(By.xpath("//label[contains(text(),'Password:')]")).getText();
		dr.findElement(By.xpath("//label[contains(text(),'Remember me?')]")).getText();
		
		//-----------------------------using contains and attribute()
		
		//label[contains(@for,'Email')]
		//label[contains(@for,'Pass')]
		//label[contains(@for,'Rem')]
		
		
	}

}
