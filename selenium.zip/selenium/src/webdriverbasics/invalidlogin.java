package webdriverbasics;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class invalidlogin {

	static String uname,uid, pwd, login, exp_res, act_res, test_res, result;
	static String enter_valid, unsucc_login, creden, no_cust,valid_mail,act_er,act_er1,act_er2;
	 static String eid;
	 static String pwd2;
	
	
	
	public static String invalid_login(){
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]/a")).click(); //click for sign in
        dr.findElement(By.xpath("//div[@class='form-fields']/form/div[2]/input")).sendKeys(uid); //uname
	 	dr.findElement(By.xpath("//div[@class='form-fields']/form/div[3]/input")).sendKeys(pwd);  // pwd
	    dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click(); //click login button
		
		dr.findElement(By.xpath("//div[@class='validation-summary-errors']/span")).getText();//login was unsuccessful
		dr.findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText();//the credentials provided are incorrect
		dr.findElement(By.xpath("//span[@class='field-validation-error']/span")).getText();//please enter a valid email address
		dr.findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText();//No customer account found
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText(); //valid mail xpath
			
		if(valid_mail.compareTo("Register")==0){
			
		       if(uid.isEmpty()==true){
		    	   
		    	   act_er=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/span")).getText();
		    	   act_er1=no_cust=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText();
		    	   String c=act_er+act_er1;
		    	   dr.close();
		    	   return c;
		    	   
		       } else {
		    	   
		    	   if(uid.contains("@gmail.com")==false){
		    		   
		    		   act_er2=dr.findElement(By.xpath("//span[@class='field-validation-error']/span")).getText();
		    		   dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click(); 
		    		   dr.close();
		    		   return act_er2;
		    		   
		    	   } else if (uid.equals(" @gmail.com")==true) {
		    		   
		    		   act_er2=dr.findElement(By.xpath("//span[@class='field-validation-error']/span")).getText();
		    		   dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click(); 
		    		   dr.close();
		    		   return act_er2;
		    		      
		    	   }  else {
		    		   
		    		   act_er=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/span")).getText();
			    	   act_er1=no_cust=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText();
			    	   String c=act_er+act_er1;
			    	   dr.close();
			    	   return c;
		    		   
		    	        }
		    	   	    	   
		       }
			 		    	   
		}
		else {
			dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]/a")).click();
			dr.close();
			return valid_mail;
		}
		
	}
	
	
	public static String read_excel(String file, String sheet, int row, int cell) {
		// TODO Auto-generated method stub
  File f=new File(file);
  String s=null;
  try {
	    FileInputStream fis = new FileInputStream(f);
	    XSSFWorkbook wb = new XSSFWorkbook(fis);
	    XSSFSheet sh = wb.getSheet(sheet);
	    XSSFRow r1 = sh.getRow(row);
	    XSSFCell c1 = r1.getCell(cell);
	    s = c1.getStringCellValue();
	    System.out.println(s);
	    
	  }  catch (IOException e) {
		                         // TODO Auto-generated catch block
		                         e.printStackTrace();
	                           } 
         return s;
	 }
//	
	
	public void writeexcel(String filename, String sheetname, int r, int c, String act_em) {
		File f=new File(filename);
		try {
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet(sheetname);
		XSSFRow row = sh.getRow(r);
		XSSFCell cell = row.createCell(c);
		

		
		
		cell.setCellValue(act_em);
		FileOutputStream fos = new FileOutputStream(f);
		wb.write(fos);
		
	
		
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String file="C:\\softwares\\demo.xlsx";
		String sheet="Sheet3";
		
		int cell=0;
		for(int row=1;row<=5;row++){
		eid = read_excel(file,sheet,row,cell);
		pwd2 = read_excel(file,sheet,row,1);
		//expectedres = read_excel(file,sheet,row,2);
		
		//invalid_login(eid,pwd2);
	}

	}
}
