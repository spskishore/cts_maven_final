package webdriverbasics;

public class substring {

	
	/*public static void abcd(){
		
	String s="www.srmist.in";
	int g=indexOf(".",0);
	int p=indexOf('.',g=g+1);
	int l=s.length();
	String last=s.substring(p,l);
	System.out.println(last);
	
	}*/

	public static void main(String[] args) {
	
		/*/String str = "www.journaldev.com";
		System.out.println("Last 4 char String: " + str.substring(str.length() - 4));
		System.out.println("First 4 char String: " + str.substring(0, 4));
		System.out.println("website name: " + str.substring(4, 14));*/
		
		//String s="I am learning java";
		/*String f=s.substring(0, 4);
		System.out.println("to extract the first 2 words: " +f);
		System.out.println("to extract the word learning: " +s.substring(5, 13));
		System.out.println("to extract the last word: " +s.substring(s.length()-4));*/
		String s="05/02/2020";
		int m=s.indexOf('/');
		System.out.println(m);
		System.out.println("date: " +s.substring(0, 2));
		int l=s.lastIndexOf('/');
		//System.out.println(l);
		System.out.println("month: "+s.substring(3,5));
		int a=s.length();
		//int a=s.indexOf('/', );
		String year=s.substring(l+1,a);
		System.out.println("year: " +year);
	}
}
