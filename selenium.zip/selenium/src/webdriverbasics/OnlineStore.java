package webdriverbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class OnlineStore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		
		String s=dr.getTitle();
		String e="Online Bookstore";
		
		if(s.compareTo(e)==0){
			System.out.println("Title verified : PASS " +s);
		} else {
			System.out.println("Title don't match");
		}
		
		WebElement we=dr.findElement(By.name("category_id"));
		Select sel=new Select(we);
		sel.selectByVisibleText("Databases");
		
      dr.findElement(By.xpath("//form/table[2]/tbody/tr[3]/td/input")).click();
      
      //----------------------------------------------------------------------
      
      String webtext=dr.findElement(By.xpath("//table[5]/tbody/tr/td/table[2]/tbody/tr/td[2]/b/a")).getText();
      String text="Web Database Development";
      
      if(webtext.compareTo(text)==0){
    	  
    	  System.out.println(webtext +" Text is displayed");
    	  
      } else {
    	  
    	  System.out.println("Text is not verified");
    	  
      }
       
      dr.findElement(By.xpath("//table[5]/tbody/tr/td/table[2]/tbody/tr/td[2]/b/a")).click();
		
      //-----------------------------------------------------------------------------
      dr.findElement(By.xpath("//form[@name='add_to_cart']/p[1]/input")).clear();
      dr.findElement(By.xpath("//form[@name='add_to_cart']/p[1]/input")).sendKeys("2");
      
      dr.findElement(By.xpath("//form[@name='add_to_cart']/p[2]/input")).click();
      
      //-------------------------------------------------------------------------------
      
      String price= dr.findElement(By.xpath("//form[@name='store_shopping']/table[2]/tbody/tr[2]/td[2]")).getText(); //price
      String qty= dr.findElement(By.xpath("//form[@name='store_shopping']/table[2]/tbody/tr[2]/td[3]/input")).getAttribute("value");//qty
      String total=dr.findElement(By.xpath("//form[@name='store_shopping']/table[2]/tbody/tr[2]/td[4]")).getText(); //total
     
      String exptotal="$79.98";
      if(exptotal.compareTo(total)==0){
    	  System.out.println("expected total is " +price +" * 2 : " +total);
      } else {
    	  
    	  System.out.println("false total value");
      }
      
          
	}

}
