package webdriverbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class explicitwait {

	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		String s="spskishore@gmail.com";
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys("spskishore@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("qwerty");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		String xp="/html/body/div[4]/div[1]/div[4]/div[1]/div[1]/div[2]/ul/li[2]/a";
		String xp1="//div[@class='add-info']/div[2]/input";
		WebElement we;
		
		WebDriverWait wt = new WebDriverWait(dr,20);
		we= wt.until(ExpectedConditions.elementToBeClickable(By.xpath(xp1)));
		we.click();
		
		
		
	}
}
