package webdriverbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class products2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		String s="spskishore@gmail.com";
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys("spskishore@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("qwerty");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		
		dr.findElement(By.xpath("//div[@class='listbox']/ul/li/a")).click();
		dr.findElement(By.xpath("//div[@class='add-info']/div[2]/input")).click();
		dr.findElement(By.xpath("//li[@id='topcartlink']/a/span[1]")).click();
		dr.findElement(By.xpath("//tr[@class='cart-item-row']/td[1]/input")).click();
		String b=dr.findElement(By.xpath("//tr[@class='cart-item-row']/td[5]/input")).getText();
		dr.findElement(By.xpath("//div[@class='common-buttons']/input")).click();
		String total=dr.findElement(By.xpath("//table[@class='cart-total']/tbody/tr[4]/td[2]//child::strong")).getText();
		System.out.println(total);
	}

}
