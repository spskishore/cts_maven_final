package testng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import webdriverbasics.login;

public class TestBasic  {
	
	
  WebDriver dr;
  basic obj;

 @BeforeMethod
  public void bm(){
      System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	  dr = new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com");
	  obj=new basic(dr);
  }

 @AfterMethod
 public void am(){
	
	dr.close();
  }
     
  @Test
  public void t1() {
	   String a=obj.login("spskishore@gmail.com","qwerty", dr);
	   System.out.println(a);
  }
  
 @Test
  public void t2() {
	 String b=obj.login("hhvh@gmail.com","H98%%439", dr);
	 System.out.println(b);
  }
 
 @Test
 public void a(){
	 SoftAssert sa=new SoftAssert();
	 sa.assertEquals(obj.exp_mail, obj.m);
	 sa.assertAll();
 }

 }