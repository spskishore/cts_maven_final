package testng;

import org.testng.annotations.Test;

public class ThreadTest {
	
	
  @Test
  public void t1() {
	  
	  System.out.println("in t1 before: ");
  
         try {
              	Thread.sleep(5000);
             } 
         catch (InterruptedException e) {
	           // TODO Auto-generated catch block
	             e.printStackTrace();
            }
  System.out.println("in t1: after");
}
  @Test
  public void t2() {
	  
	  System.out.println("in t2 before: ");
  
           try {
	               Thread.sleep(5000);
               } 
           catch (InterruptedException e) {
	                     // TODO Auto-generated catch block
	                             e.printStackTrace();
                               }
           System.out.println("in t2 after:");
  
}
  
 
}