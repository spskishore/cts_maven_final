package testng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class basic {

      static WebDriver dr;
	static String exp_mail,m;
	

	
	public static String login(String uid, String pwd, WebDriver dr) {
		// TODO Auto-generated method stub
	
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[2]/input")).sendKeys(uid);
		exp_mail = dr.findElement(By.xpath("//div[@class='form-fields']/form/div[2]/input")).getText(); 
		System.out.println(exp_mail);//uname
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[3]/input")).sendKeys(pwd); //pwd
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click();
	 m= dr.findElement(By.xpath("//div[@class='header-links-wrapper']/div[1]/ul/li[1]/a")).getText();
		return m;
	}


	
	public basic(WebDriver dr){
		this.dr=dr;
	}

	
}
