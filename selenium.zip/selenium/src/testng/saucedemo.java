package testng;

public class saucedemo {
	
	public static void login(){ 
	
		System.out.println("login successful");
	
}
	
}