package simple;

import org.apache.log4j.Logger;

public class logger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Logger log=Logger.getLogger("devpinoyLogger");
      log.debug("Error happened");
      log.info("info msg");
	}

}
