package date_picker;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class date_pick1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver dr;
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get("https://www.redbus.in/");
		
		try {
			Thread.sleep(4000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
		  String exp_date = "01-May-2020"; 
		  String exp_year="May 2020";
	        String[] arrOfStr = exp_date.split("-", 3); 
	  
	        for (String a : arrOfStr) 
	            System.out.println(a);
	        
	      
	        exp_date=arrOfStr[0];
	     String   exp_month=arrOfStr[1];
	        exp_year=arrOfStr[2];
	        String x=exp_month+" ";
	        String y=x+exp_year;
	        dr.findElement(By.xpath("//input[@id='onward_cal']")).click();
	     String act_year= dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[2]")).getText();
	     
	     while(!exp_year.equals(act_year))
			{
				dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[3]")).click();
			    act_year=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
		
		}
	      
	     List <WebElement> rb=dr.findElements(By.xpath("//div[@class='rb-calendar']//child::td"));
			for(WebElement ele:rb)
			{
				String date=ele.getText();
				if(exp_date.equalsIgnoreCase(date))
				{
					ele.click();
					
				}
			}  
	        
	}

}
