package date_picker;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class date_pick {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver dr;
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get("http://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html");
		
		
		String exp_year="December 2020";
		String exp_date="25";
		
		dr.findElement(By.xpath("//input[@id='datepicker']")).click();
		String act_year=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
		
		while(!exp_year.equals(act_year))
		{
			dr.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();
		    act_year=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
	
	}

		List <WebElement> rb=dr.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//child::td"));
		for(WebElement ele:rb)
		{
			String date=ele.getText();
			if(exp_date.equalsIgnoreCase(date))
			{
				ele.click();
				
			}
		}
	}
}
