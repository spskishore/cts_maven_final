package pom_test;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pom.home_page;
import pom.login_page;

public class Test_login {
	
	
	WebDriver dr;
	login_page lp;
	home_page hp;
	
	
	@BeforeClass
	public void launch_brow()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
	}
	
  @Test(priority=0)
  public void test_loginpage() {
	  
	  lp=new login_page(dr);
	  String lp_title=lp.get_title();
	  Assert.assertTrue(lp_title.contains("Shop"));
  }
  
  @Test(priority=1)
  public void test_homepage() {
	  
	  hp=new home_page(dr);
	 lp.do_login("spskishore@gmail.com", "qwerty");
	  String actual_eid=hp.get_displayed();
	  Assert.assertTrue(actual_eid.contains("spskishore@gmail.com"));
  }
}
