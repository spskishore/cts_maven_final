package pom_test;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.utilities;
import pom.home_page;
import pom.login_page;

public class Test_login_fir extends utilities{

	

	

	
	login_page lp;
	home_page hp;
	
	
	@BeforeMethod
	public void launch_brow()
	{
		System.setProperty("webdriver.geckop.driver","geckodriver.exe");
	    dr=new FirefoxDriver();
		dr.get("http://demowebshop.tricentis.com/login");
	}
	
//  @Test(priority=0)
//  public void test_loginpage() {
//	  
//	  lp=new login_page(dr);
//	  String lp_title=lp.get_title();
//	  Assert.assertTrue(lp_title.contains("Shop"));
//  }
  
  @Test(dataProvider="login")
  public void test(String uid, String pwd, String exp_eid) {
	  lp=new login_page(dr); 
	  lp.do_login(uid,pwd);
	  
	 hp=new home_page(dr);
	  String actual_eid=hp.get_displayed();
	SoftAssert sa=new SoftAssert();
	sa.assertEquals(actual_eid, exp_eid);
	sa.assertAll();
  }
  
  @DataProvider(name="login")
	public String[][] prov_data(){
	  
	  get_test_data();
		return testdata;
	}
  
  @AfterMethod
  public void am() {
	  dr.close();
  }
}
