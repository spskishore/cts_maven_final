package Day_1;

public class Pgm6 {

	public static void main(String[] args) {
		
		long sal=500000;
		double s2,s3,t2 = 0,t3 = 0,t4,s4,tax=0;
		if(sal>0 && sal<=180000){
			
			System.out.println("you have to pay "+tax);
		}
		else  if(sal>180000 && sal<=500000) {
			
			s2=sal-180000;
			t2=s2*0.1;
	    	System.out.println("you have to pay "+t2);
		}
else  if(sal>500000 && sal<=800000) {
			
			s3=sal-500000;
			t3=(s3*0.2)+t2;
	    	System.out.println("you have to pay "+t3);
		}
else if(sal>800000){
	
	s2=sal-180000;
	t2=s2*0.1;
	s3=sal-500000;
	t3=(s3*0.2)+t2;
	s4=sal-800000;
	t4=(s4*0.3)+t2+t3;
	System.out.println("you have to pay "+t4);
}
		
	
	}
}
