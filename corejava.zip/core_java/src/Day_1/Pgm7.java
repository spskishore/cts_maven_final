package Day_1;

public class Pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=10;
switch(i) {
case 20: System.out.println("abc");
          break;
case 30: System.out.println("qwe");
          break;
case 40: System.out.println("bnm");
          break;
default:System.out.println("jojojojo");
        break;
}
		

}
}
