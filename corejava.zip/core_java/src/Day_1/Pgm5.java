package Day_1;

public class Pgm5 {

public static void main(String[] args) {
		
		
		int a=10, b=3, c=15;
		if(a<b) {
			if(a<c) 
			System.out.println(a+" is lesser than " + b + " and " + c);
			else
				System.out.println(c+ " is lesser than " + a + " and " + b);	
							
		}
		else if(b<a){
			if(b<c)
			System.out.println(b+ " is lesser than " +a + " and " + c);
			else
				System.out.println(c+ " is lesser than " + a + " and " + b);	
				
		}
		
}
}
