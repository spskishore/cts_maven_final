package Day_1;

public class Pgm4 {
	
	public static void main(String[] args) {
		
		
		int a=20, b=8, c=10;
		if(a<b && a<c) {
			System.out.println(a+" is lesser than " + b + " and " + c);
		} 
		else if(b<a && b<c){
			System.out.println(b+ " is lesser than " +a + " and " + c);
		}
		else {
			System.out.println(c+ " is lesser than " + b + " and " + c);
		}
		
		
	}
}

