package Day_1;

public class Pgm10 {
	public static void main(String[] args) {
	
       int num=75,n;
       while(num>0)  {
    	   
    	   for(int i=15;i<=75;i++) {
    		 n=i%7;
    		   System.out.println(n);
    	   
    	   }
       }
    	   
	
	}
}
