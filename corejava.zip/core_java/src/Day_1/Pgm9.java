package Day_1;

public class Pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n=1234,r,sum=0;;
		while(n>0){
			
			r=n%10;
			sum=sum+r;
			n=n/10;
		
		}
		System.out.println(sum);
	}

}
