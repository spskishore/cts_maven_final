package Day5;

public abstract class bank {
	
	public  float roi(){
  	  
        return 0f;

     }
	public void show(){
		System.out.println("Bank Details: ");
	}
	
}
