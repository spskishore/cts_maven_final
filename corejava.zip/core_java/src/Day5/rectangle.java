package Day5;

public class rectangle implements draw {

	public void draw(){
		System.out.println("rectangle");
	}
}
