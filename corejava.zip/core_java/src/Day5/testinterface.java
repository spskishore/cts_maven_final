package Day5;

public class testinterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      draw d = new rectangle();
      d.draw();
	}

}
