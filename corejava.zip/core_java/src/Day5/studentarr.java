package Day5;

import java.util.ArrayList;

public class studentarr {
	ArrayList<student> stdal=new ArrayList<student>();
	public static studentarr ob;
	public void create_stdal()
	{
		
		student s1=new student(232,"Kishore",95,98);
		student s2=new student(765,"Abraham",99,80);
		stdal.add(s1);
		stdal.add(s2);
		
	}
	public  void display_stdal() 
	{
		
		for(student s : stdal)
		{
			
			System.out.println("Name: "+s.name + " id: "+s.id +" sel: "+s.sel +" java: "+s.java +" avg: " +s.cal_avg());
		}
	}
	

	public static void main(String[] args) {
		
	studentarr	ob = new studentarr();
	   ob.create_stdal();
		ob.display_stdal();
		
	}

}
