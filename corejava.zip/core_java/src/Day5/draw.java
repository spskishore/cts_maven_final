package Day5;

public interface draw {

	void draw();
}
