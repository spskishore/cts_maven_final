package Day5;

public class student {

	int id;
	String name;
	int sel;
	int java;
	float avg;
	
	public student(int id,String name,int sel,int java)
	{
		this.id=id;
		this.sel=sel;
		this.java=java;
		this.name=name;
	}

	public float cal_avg() {
		
		avg=(sel+java)/2.0f;
	  return avg;
	}

}
