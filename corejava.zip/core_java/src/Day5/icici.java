package Day5;

public class icici extends bank{

	 public float roi(){
   	  
         return 7.8f;

      }
}
