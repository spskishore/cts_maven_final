package Day5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class getexcel2 {

	
	public void getexcel(String filename, String sheetname, int r, int c) throws IOException{
		
		 File f = new  File("C:\\softwares\\demo.xlsx");
		 FileInputStream fis = new FileInputStream(f);
		    XSSFWorkbook wb = new XSSFWorkbook(fis);
		    XSSFSheet sh = wb.getSheet("Sheet1");
		    XSSFRow row = sh.getRow(0);
		    XSSFCell cell = row.getCell(0);
		    String s = cell.getStringCellValue();
		    System.out.println(s);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
     
     
	}

}
