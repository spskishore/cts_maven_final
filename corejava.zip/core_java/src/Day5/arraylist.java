package Day5;

import java.util.ArrayList;

public class arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> al=new ArrayList<String>();
		ArrayList<Integer> bl=new ArrayList<Integer>();
		
al.add("abc");
al.add("book");
al.add("table");
al.add("wheel");

bl.add(45);
bl.add(1245);
bl.add(365);
bl.add(95);

System.out.println(bl);
bl.add(2,666);
System.out.println(bl);
bl.remove(3);
System.out.println(bl);

System.out.println("Before Insertion: " +al);
al.add(2,"pen");
System.out.println("After Insertion: " +al);
al.remove("table");
System.out.println("After Deletion: " +al);
al.remove(0);
System.out.println("After Deletion: " +al);

for(String s : al) {
	 
	 System.out.println(s);
}

	}

}
