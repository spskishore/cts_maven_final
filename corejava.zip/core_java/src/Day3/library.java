package Day3;

public class library {

	public float add(int x, float y) {
		float z= x+y;
		return z;
	}
}