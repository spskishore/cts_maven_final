package Day3;

public class Animal {

	int h,w,a;
	String c;
	char g;
	
	public void display() {
		
		System.out.println(" height: " +h +" weight: " +w + " age: " +a +" gender: " +g +" color: " +c);
	}

}
