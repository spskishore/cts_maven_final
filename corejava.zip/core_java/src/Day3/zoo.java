package Day3;

public class zoo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        Elephant s=new Elephant();
        s.a=10;
        s.h=8;
        s.w=40;
        s.c="grey";
        s.g='f';
        s.lotruck=10;
        s.lotusk=15;
       
        s.dispele();
		
	}

}
