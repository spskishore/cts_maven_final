package Day3;

public class Elephant extends Animal{

	int lotruck,lotusk;
	
	public void dispele() {
		super.display();
		System.out.println("lotruck is: "+lotruck +" lotusk is: " +lotusk);
		
	}
	
	
}
