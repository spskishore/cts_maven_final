package Day3;

public class College {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		student kishore=new student();
		kishore.sel=90;
		kishore.java=95;
		kishore.cal_avg();
		
	}

}

