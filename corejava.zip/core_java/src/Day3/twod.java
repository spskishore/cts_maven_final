package Day3;


import java.util.Scanner;

public class twod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    String[][] emp = {{ "e1","bob"},{"e2","maz"},{"e3","david"},{"e4","robin"},{"e5","kevin"}};
      Scanner in= new Scanner(System.in);
     String v=in.next();
    
   for(int r=0;r<=4;r++){ 	   
         for(int c=0;c<=1;c++){
	     
	
	           }

        }
	}
}