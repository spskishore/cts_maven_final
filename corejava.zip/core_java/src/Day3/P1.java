package Day3;
import java.util.Scanner;
public class P1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  
		Scanner in=new Scanner(System.in);
		char c=in.next().charAt(0);
		int counter=0;
		while(c!='n') 
		  {
			
			
		   if(c=='a' || c=='e' || c=='i' || c=='o' || c=='u')
			counter++;
		   c=in.next().charAt(0);
		}
		System.out.println(counter);
		}
	}


