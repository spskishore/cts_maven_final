package Day3;

public class calc  extends library{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		calc obj=new calc();
		float f= obj.add(4, 3.5f);
		System.out.println(f);
	}

}
