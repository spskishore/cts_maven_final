package Day3;

public class student {

	int id;
	String name;
	int sel;
	int java;
	float avg;

	public void cal_avg() {
		avg=(sel+java)/2.0f;
		System.out.println(avg);
	}

}
