package Day3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Dab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f = new File("C:\\softwares\\dab.xlsx");
		try {
			
			 FileInputStream fis = new FileInputStream(f);
			    XSSFWorkbook wb = new XSSFWorkbook(fis);
			    XSSFSheet sh = wb.getSheet("Sheet1");
			    XSSFRow row = sh.getRow(0);
			    XSSFCell cell = row.getCell(0);
			    String s = cell.getStringCellValue();
			    System.out.println(s);
			    
			    cell.setCellValue("Oneplus");
			    FileOutputStream fos = new FileOutputStream(f);
			    wb.write(fos);
				
		}
		catch(IOException e){
			
			e.printStackTrace();
		}
		
		File f1 = new File("C:\\softwares\\dab.xlsx");
		try {
			
			FileInputStream fis = new FileInputStream(f);
		    XSSFWorkbook wb = new XSSFWorkbook(fis);
		    XSSFSheet sh2 = wb.getSheet("Sheet2");
		    XSSFRow r2 = sh2.getRow(0);
		    XSSFCell c2 = r2.getCell(0);
		
		  
		    
		    c2.setCellValue("kriz");
		    FileOutputStream fos = new FileOutputStream(f);
		    wb.write(fos);		
		}
catch(IOException e){
			
			e.printStackTrace();
		}

		
		
			
		
	}

}
