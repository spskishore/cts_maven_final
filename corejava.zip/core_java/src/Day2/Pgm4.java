package Day2;

public class Pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Chennai",s2="chennai";
		int l=s.length();
		System.out.println("length: "+l); 
		
		int c=s.compareTo(s2);
		System.out.println(c);
		
		s2=s.substring(0, 3);
		System.out.println("substring:" + s2); 
		
		int p=s.indexOf("n",0);
		System.out.println("position of 1st n: "+p);
		
		int p1=s.indexOf("n",p+1);
		System.out.println("position of 2nd n: "+ p1);
		

	}

}
