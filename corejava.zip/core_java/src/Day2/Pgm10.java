package Day2;

public class Pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] n= {{20,44,87,9},{65,-7,32,8},{54,76,4,43}};
    
     for(int r=0;r<=2;r++)
    	 for(int c=0;c<=3;c++){
    		 int max=n[r][0];
    		 
    		 if(n[r][c]>max){
    			  max=n[r][c];
    			  System.out.println(max);
    		 }
    		 
    		 
    		 
    	 }
    		    	 		 
	}

}
