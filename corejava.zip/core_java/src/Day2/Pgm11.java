package Day2;

public class Pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="malayalam";
		 char tofind='a';
		 int occurence=0;
		 
		 for(int i=0;i<s.length();i++) {
			 
			 if(s.charAt(i)==tofind)
				 occurence=occurence+1;
			 

		 }
		System.out.println(tofind+ " has occured " +occurence+ " no of times");	 
		 
	}

}
