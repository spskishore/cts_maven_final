package Day2;

public class Pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int [] marks={95,91,85,86,90,77,71,81};
   int sum=0;
   for(int i=0;i<=7;i+=2){
	   if(marks[i]%2==1) 
	   sum=sum+marks[i];}
	   
		   
		   System.out.println(sum);
	   
   }

	}


