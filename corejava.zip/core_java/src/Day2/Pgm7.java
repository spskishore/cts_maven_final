package Day2;

public class Pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10, b=0;
int[] m={1,3,5,6};
try {
	System.out.println("sup");
    int c=a/b;
System.out.println("bruh"); 
}
catch(Exception e) {
	System.out.println("catch");
}

System.out.println(m[3]);
	}

}
