package Day2;

public class Pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] marks={90,80,70,93,72,63,75,99};
		float sum=0;
		for(int i=0;i<=7;i++) {
			sum=sum + marks[i];
			
		}
		float avg=sum/8;
		System.out.println(avg);
		if(avg>=70){
			System.out.println("First Class with Distinction"); }
		else if(avg>=60 && avg<70) {
			System.out.println("First Class"); }
			else if(avg>=50 && avg<60) {
				System.out.println("Second Class"); }
			else {
				System.out.println("Fail");
		}
	}

}
