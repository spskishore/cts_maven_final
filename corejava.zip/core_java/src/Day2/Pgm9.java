package Day2;

public class Pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int max=0;
		int m[]={18,4,-2,29};
		max=m[0];
		for(int r=0;r<=3;r++){
		
		if(m[r]>max) {
			
		    	max=m[r];
				System.out.println(max);
				
		}	
		
		}		
	}
}
		


