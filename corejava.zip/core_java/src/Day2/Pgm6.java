package Day2;

public class Pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String s="I am learning core java";
	       int i=0,p=0,c=0;
	       
	       while(p>=0){
	    	   
	    	   p=s.indexOf(" ",i);
	    
	    	   if(p==-1) 
	    	  p=s.length();
	    	   
	  	String  s1=s.substring(i,p);
	    	   i=p+1;
	    	   System.out.println("i= "+i +" p= "+p );
	       }
	       
	       c=c-1;
 
		
	 
	}

}
