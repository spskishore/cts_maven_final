package Day2;

public class Pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		int[][] m={{75,80,85},{20,21,33}};
		for(int r=0;r<=1;r++){
			
			for(int c=0;c<=2;c++) 
				if(m[r][c]%2==0)
				sum=sum+m[r][c];
				
			}
		System.out.println(sum);
		
	}

}
