package Day2;

public class Pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10, b=2;
		int[] m={1,3,5,6};
		try {
			int c=a/b;
			System.out.println(m[4]);
		}
		catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println("AE");
		}
		System.out.println("outside catch");
	}

}
