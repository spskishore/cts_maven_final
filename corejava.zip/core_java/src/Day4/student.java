package Day4;

public class student {

	int id;
	String name;
	int sel;
	int java;
	float avg;
	
	public student(int sel,int java)
	{
		this.sel=sel;
		this.java=java;
	}

	public void cal_avg() {
		avg=(sel+java)/2.0f;
	
	}

}
