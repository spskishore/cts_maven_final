package Day4;

public class std {	
	 static String[][] stud = {{ "81","bob"},{"15","maz"},{"21","david"},{"11","robin"},{"35","kevin"}};
	 static int[][] m = {{81,60,98},{15,96,56},{21,87,100},{11,45,55},{35,90,95}};
	 
	 static float avg;
	 static int i;
	 int index;
	static String n;	

	 public static  int cal_avg(int i) {
		 
		   int avg; 
		  avg=(m[i][1]+m[i][2])/2;
		  return avg;
	 }

	 public static int search(String sid1){ //searches std id in marks arr
		 int index = 0;
		 int id=Integer.parseInt(sid1);
	        for(int i=0;i<=4;i++)
	        {
	      	  if(id==m[i][0]){
	      		          index=i;
	      	              break; 
	      	      }
	      	  
	        }
		
			 return index;
	        
		    
	 }
	 
	 public static String getname(String stdid){
		 String n = null;
		 for(int j=0;j<=4;j++){
			 if(stdid.equals(stud[j][0]))
			 {
				 n=stud[j][1];
				 break;
			 }
		 }
		 return n;
	 }
	 
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int k=search("35");    
	   int id=Integer.parseInt("35");
	  
	int average=std.cal_avg(k);   
	String name=std.getname("35");
		
		System.out.println(" id: " +id +" avg: "+average+ " "+" name: " +name);
	}

}
