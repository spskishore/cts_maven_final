package Day4;

public class bank1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
bank b;
		b=new icici();
		System.out.println("ICICI ROI is: "+b.roi());
		
		b=new hdfc();
		System.out.println("HDFC ROI is: "+b.roi());
	}

}
