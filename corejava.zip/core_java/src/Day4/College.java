package Day4;

public class College {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	 student s=new student(80,90);
	 s.cal_avg();

	 System.out.println(s.avg);
		
		
		
	}

}

