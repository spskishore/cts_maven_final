package Day4;

public class methodover {

	public int add(int a, int b){
		int c=a+b;
		System.out.println("adding 2 var");
		System.out.println(c);
		return c;
	}
	
public int add(int x, int y, int s){
	int e=x+y+s;
	System.out.println(e);
	return e;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     methodover ob=new methodover();
     int m=ob.add(4,5);
     int n=ob.add(10, 5, 20);
    		
	}

}
