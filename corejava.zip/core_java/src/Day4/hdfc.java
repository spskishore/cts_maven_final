package Day4;

public class hdfc extends bank{
	
      public float roi(){
    	  
	             return 6.7f;
	
              }
}
